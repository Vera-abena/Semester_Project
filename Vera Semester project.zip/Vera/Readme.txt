Name:Takyi Vera
Index no:UEB3247522
Class:IT c

A C++ project is designed with an object-oriented approach, with classes for
customers, accounts, transactions, and banking services. Features included
creating and managing customers, accounts, and transactions, as well as
performing banking services such as withdrawals, deposits, and transfers. It also
allows customers to view their account information, including account balances,
recent transactions, and other details