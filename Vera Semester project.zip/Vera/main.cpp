#include <iostream>
#include <vector>

class Transaction {
public:
    Transaction(double amount, const std::string& type)
        : amount(amount), type(type) {}

    double getAmount() const {
        return amount;
    }

    std::string getType() const {
        return type;
    }

private:
    double amount;
    std::string type;
};

class Account {
public:
    Account(int accountNumber, double balance = 0.0)
        : accountNumber(accountNumber), balance(balance) {}

    int getAccountNumber() const {
        return accountNumber;
    }

    double getBalance() const {
        return balance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactions.push_back(Transaction(amount, "Deposit"));
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactions.push_back(Transaction(amount, "Withdrawal"));
        }
    }

    void displayTransactions() const {
        for (size_t i = 0; i < transactions.size(); ++i) {
            const Transaction& transaction = transactions[i];
            std::cout << "Type: " << transaction.getType()
                      << ", Amount: " << transaction.getAmount() << std::endl;
        }
    }

private:
    int accountNumber;
    double balance;
    std::vector<Transaction> transactions;
};

class Customer {
public:
    Customer(int customerId, const std::string& name)
        : customerId(customerId), name(name) {}

    int getCustomerId() const {
        return customerId;
    }

    std::string getName() const {
        return name;
    }

private:
    int customerId;
    std::string name;
};

class BankingService {
public:
    void createCustomer(int customerId, const std::string& name) {
        customers.push_back(Customer(customerId, name));
    }

    void createAccount(int customerId, int accountNumber, double initialBalance = 0.0) {
        for (size_t i = 0; i < customers.size(); ++i) {
            if (customers[i].getCustomerId() == customerId) {
                customerAccounts.push_back(Account(accountNumber, initialBalance));
                break;
            }
        }
    }

    Account* getAccount(int accountNumber) {
        for (size_t i = 0; i < customerAccounts.size(); ++i) {
            if (customerAccounts[i].getAccountNumber() == accountNumber) {
                return &customerAccounts[i];
            }
        }
        return NULL;
    }

private:
    std::vector<Customer> customers;
    std::vector<Account> customerAccounts;
};

int main() {
    BankingService bankingService;

    while (true) {
        std::cout << "Choose an action:" << std::endl;
        std::cout << "1. Create Customer" << std::endl;
        std::cout << "2. Create Account" << std::endl;
        std::cout << "3. Deposit" << std::endl;
        std::cout << "4. Withdraw" << std::endl;
        std::cout << "5. Transfer Funds" << std::endl;
        std::cout << "6. Display Account Information" << std::endl;
        std::cout << "7. Exit" << std::endl;

        int choice;
        std::cin >> choice;

        if (choice == 1) {
            int customerId;
            std::string name;
            std::cout << "Enter Customer ID: ";
            std::cin >> customerId;
            std::cout << "Enter Customer Name: ";
            std::cin.ignore();
            std::getline(std::cin, name);
            bankingService.createCustomer(customerId, name);
        } else if (choice == 2) {
            int customerId, accountNumber;
            double initialBalance;
            std::cout << "Enter Customer ID: ";
            std::cin >> customerId;
            std::cout << "Enter Account Number: ";
            std::cin >> accountNumber;
            std::cout << "Enter Initial Balance: ";
            std::cin >> initialBalance;
            bankingService.createAccount(customerId, accountNumber, initialBalance);
        } else if (choice == 3) {
            int accountNumber;
            double amount;
            std::cout << "Enter Account Number: ";
            std::cin >> accountNumber;
            std::cout << "Enter Deposit Amount: ";
            std::cin >> amount;
            Account* account = bankingService.getAccount(accountNumber);
            if (account) {
                account->deposit(amount);
            } else {
                std::cout << "Account not found." << std::endl;
            }
        } else if (choice == 4) {
            int accountNumber;
            double amount;
            std::cout << "Enter Account Number: ";
            std::cin >> accountNumber;
            std::cout << "Enter Withdrawal Amount: ";
            std::cin >> amount;
            Account* account = bankingService.getAccount(accountNumber);
            if (account) {
                account->withdraw(amount);
            } else {
                std::cout << "Account not found." << std::endl;
            }
        } else if (choice == 5) {
            int fromAccount, toAccount;
            double amount;
            std::cout << "Enter source Account Number: ";
            std::cin >> fromAccount;
            std::cout << "Enter destination Account Number: ";
            std::cin >> toAccount;
            std::cout << "Enter Transfer Amount: ";
            std::cin >> amount;
            
            Account* sourceAccount = bankingService.getAccount(fromAccount);
            Account* destAccount = bankingService.getAccount(toAccount);

            if (sourceAccount && destAccount) {
                if (sourceAccount->getBalance() >= amount) {
                    sourceAccount->withdraw(amount);
                    destAccount->deposit(amount);
                    std::cout << "Transfer successful." << std::endl;
                } else {
                    std::cout << "Insufficient balance for transfer." << std::endl;
                }
            } else {
                std::cout << "Invalid account number(s)." << std::endl;
            }
        } else if (choice == 6) {
            int accountNumber;
            std::cout << "Enter Account Number: ";
            std::cin >> accountNumber;
            Account* account = bankingService.getAccount(accountNumber);
            if (account) {
                std::cout << "Account Balance: " << account->getBalance() << std::endl;
                std::cout << "Transactions:" << std::endl;
                account->displayTransactions();
            } else {
                std::cout << "Account not found." << std::endl;
            }
        } else if (choice == 7) {
            std::cout << "Exiting the program." << std::endl;
            break;
        } else {
            std::cout << "Invalid choice. Please select a valid option." << std::endl;
        }
    }

    return 0;
}
